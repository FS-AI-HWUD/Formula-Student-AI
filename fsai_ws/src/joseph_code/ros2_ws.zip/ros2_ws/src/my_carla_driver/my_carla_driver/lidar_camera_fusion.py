#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import time
import cv2
import os
import open3d as o3d
from threading import Lock
from sensor_msgs.msg import Image, PointCloud2, CameraInfo
from std_msgs.msg import Header
import sensor_msgs_py.point_cloud2 as pc2
from cv_bridge import CvBridge
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped, Transform, Vector3, Quaternion
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from std_msgs.msg import ColorRGBA
import carla
import sys
import threading
import torch
from sklearn.cluster import DBSCAN

# Import your existing modules
from .zed_2i import Zed2iCamera  # Import from the same package # Will need to modify this # Will need to modify this
from .path_planning import PathPlanner


def transform_points(points, transform):
    """
    Transform an array of points (N x 3) using a 4x4 transformation matrix.
    """
    ones = np.ones((points.shape[0], 1))
    points_hom = np.hstack((points, ones))
    points_world = (transform @ points_hom.T).T[:, :3]
    return points_world


class LidarCameraFusionNode(Node):
    def __init__(self):
        super().__init__('lidar_camera_fusion_node')
        
        # Declare parameters
        self.declare_parameter('model_path', '/home/dalek/Desktop/runs/detect/train8/weights/best.pt')
        self.declare_parameter('use_carla', True)
        self.declare_parameter('carla.host', 'localhost')
        self.declare_parameter('carla.port', 2000)
        self.declare_parameter('carla.timeout', 10.0)
        self.declare_parameter('output_dir', '/home/dalek/attempt_1/Lidar_test/dataset')
        self.declare_parameter('show_opencv_windows', True)
        self.declare_parameter('lidar_point_size', 0.4)  # Increased default point size
        self.declare_parameter('pointnet_model_path', '/home/dalek/attempt_1/pointnet_detector.pth')
        self.declare_parameter('accumulate_lidar_frames', 3)  # Number of frames to accumulate
        
        # Get parameters
        self.model_path = self.get_parameter('model_path').value
        self.use_carla = self.get_parameter('use_carla').value
        self.carla_host = self.get_parameter('carla.host').value
        self.carla_port = self.get_parameter('carla.port').value
        self.carla_timeout = self.get_parameter('carla.timeout').value
        self.output_dir = self.get_parameter('output_dir').value
        self.show_opencv_windows = self.get_parameter('show_opencv_windows').value
        self.lidar_point_size = self.get_parameter('lidar_point_size').value
        self.pointnet_model_path = self.get_parameter('pointnet_model_path').value
        self.accumulate_frames = self.get_parameter('accumulate_lidar_frames').value
        
        # Bridge for converting between ROS and OpenCV images
        self.bridge = CvBridge()
        
        # Create publishers
        self.rgb_pub = self.create_publisher(Image, '/carla/rgb_image', 10)
        self.depth_pub = self.create_publisher(Image, '/carla/depth_image', 10)
        self.path_pub = self.create_publisher(Image, '/carla/path_image', 10)
        self.lidar_pub = self.create_publisher(PointCloud2, '/carla/lidar_points', 10)
        self.fused_pub = self.create_publisher(PointCloud2, '/carla/fused_points', 10)
        self.cone_marker_pub = self.create_publisher(MarkerArray, '/carla/lidar_cones', 10)
        
        # Transform broadcaster for tf tree
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # Initialize state variables
        self.world = None
        self.vehicle = None
        self.zed_camera = None
        self.path_planner = None
        self.lidar = None
        self.lidar_data = None
        self.lidar_lock = Lock()
        self.vis_thread = None
        
        # Initialize LiDAR history for point accumulation
        self.lidar_history = []
        self.lidar_history_lock = Lock()
        
        # Timer for main processing
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz
        
        # Setup Carla and sensors
        self.setup()
    
    def setup(self):
        """Initialize Carla, vehicle, camera, and LiDAR."""
        if not self.use_carla:
            self.get_logger().info("Carla integration disabled")
            return False
            
        try:
            client = carla.Client(self.carla_host, self.carla_port)
            client.set_timeout(self.carla_timeout)
            self.get_logger().info("Connecting to CARLA server...")
            
            self.world = client.get_world()
            self.get_logger().info("Connected to CARLA world successfully")
            
            self.vehicle = self.spawn_vehicle()
            if not self.vehicle:
                self.get_logger().error("Failed to spawn vehicle")
                return False
                
            # Initialize ZED camera
            self.zed_camera = Zed2iCamera(self.world, self.vehicle, 
                                         resolution=(1280, 720), 
                                         fps=30, 
                                         model_path=self.model_path)
            
            if not self.zed_camera.setup():
                self.get_logger().error("Failed to setup ZED camera")
                return False
                
            # Initialize path planner
            self.path_planner = PathPlanner(self.zed_camera, 
                                           depth_min=1.0, 
                                           depth_max=20.0, 
                                           cone_spacing=1.5, 
                                           visualize=True)
            
            # Setup LiDAR
            if not self.setup_lidar():
                self.get_logger().error("Failed to setup LiDAR")
                return False
                
            # Enable OpenCV windows if configured
            if self.show_opencv_windows:
                self.vis_thread = threading.Thread(target=self.visualization_thread)
                self.vis_thread.daemon = True
                self.vis_thread.start()
                self.get_logger().info("OpenCV visualization enabled")
            else:
                self.get_logger().info("OpenCV visualization disabled (use RViz)")
                
            self.get_logger().info("Carla setup completed successfully")
            return True
                
        except Exception as e:
            self.get_logger().error(f"Error setting up Carla: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return False
    
    def spawn_vehicle(self):
        """Spawn a vehicle in the CARLA world."""
        try:
            blueprint_library = self.world.get_blueprint_library()
            vehicle_bp = blueprint_library.filter('vehicle.*')[0]
            if not vehicle_bp:
                self.get_logger().error("No vehicle blueprints found")
                return None
                
            self.get_logger().info(f"Using vehicle blueprint: {vehicle_bp.id}")
            
            spawn_transform = carla.Transform(
                carla.Location(x=-35.0, y=0.0, z=5.0),
                carla.Rotation(pitch=0.0, yaw=0.0, roll=0.0)
            )
            vehicle = self.world.spawn_actor(vehicle_bp, spawn_transform)
            self.get_logger().info(f"Vehicle spawned at {spawn_transform.location}")
            
            time.sleep(2.0)
            if not vehicle.is_alive:
                self.get_logger().error("Vehicle failed to spawn or is not alive")
                return None
            return vehicle
        except Exception as e:
            self.get_logger().error(f"Error spawning vehicle: {str(e)}")
            return None
    
    def setup_lidar(self):
        """Setup LiDAR sensor."""
        try:
            # Setup LiDAR sensor
            lidar_bp = self.world.get_blueprint_library().find('sensor.lidar.ray_cast')
            if not lidar_bp:
                self.get_logger().error("LiDAR blueprint not found")
                return False
                
            # Configure LiDAR attributes
            lidar_bp.set_attribute('channels', '128')
            lidar_bp.set_attribute('points_per_second', '1000000')
            lidar_bp.set_attribute('rotation_frequency', '20')
            lidar_bp.set_attribute('range', '100')
            lidar_bp.set_attribute('upper_fov', '30')
            lidar_bp.set_attribute('lower_fov', '-30')
            
            # Position LiDAR above the vehicle
            lidar_transform = carla.Transform(carla.Location(x=1.5, z=2.2))
            self.get_logger().info(f"Spawning LiDAR at {lidar_transform.location}")
            
            self.lidar = self.world.spawn_actor(lidar_bp, lidar_transform, attach_to=self.vehicle)
            
            # Listen to LiDAR data
            self.lidar.listen(lambda data: self._lidar_callback(data))
            self.get_logger().info("LiDAR sensor spawned successfully")
            
            return True
        except Exception as e:
            self.get_logger().error(f"Error setting up LiDAR sensor: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return False
    
    def _lidar_callback(self, data):
        """Callback to process LiDAR data (runs in sensor thread)."""
        try:
            # Process raw LiDAR data into an (N, 4) array and keep only x, y, z
            points = np.frombuffer(data.raw_data, dtype=np.dtype('f4'))
            points = np.reshape(points, (-1, 4))
            
            with self.lidar_lock:
                self.lidar_data = points[:, :3]
                self.lidar_frame = data.frame
                self.lidar_timestamp = data.timestamp
            
            self.get_logger().debug(f"Captured {len(self.lidar_data)} LiDAR points")
            
            # Save PCD file every 10 frames
            if hasattr(self, 'output_dir') and data.frame % 10 == 0:
                pcd_temp = o3d.geometry.PointCloud()
                pcd_temp.points = o3d.utility.Vector3dVector(points[:, :3])
                pcd_path = os.path.join(self.output_dir, f"lidar_{data.frame:04d}.pcd")
                o3d.io.write_point_cloud(pcd_path, pcd_temp)
                self.get_logger().info(f"Saved PCD to {pcd_path}")
        except Exception as e:
            self.get_logger().error(f"Error in LiDAR callback: {str(e)}")
    
    def timer_callback(self):
        """Main processing loop."""
        if not self.use_carla or not self.vehicle or not self.zed_camera:
            return
            
        try:
            # Process camera frame
            self.zed_camera.process_frame()
            
            # Plan path
            self.path_planner.plan_path()
            
            # Process LiDAR data
            self.process_lidar_data()
            
            # Fuse LiDAR and camera data
            self.fuse_data()
            
            # Publish data for visualization
            self.publish_data()
            
            # Broadcast transforms
            self.broadcast_tf()
            
        except Exception as e:
            self.get_logger().error(f"Error in timer callback: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def detect_cones_from_lidar(self, lidar_points):
        """
        Use PointNet model to detect cones from LiDAR point cloud
        
        Args:
            lidar_points: Numpy array of shape (N, 3) containing LiDAR points
            
        Returns:
            list of detected cones with position and confidence
        """
        try:
            if not hasattr(self, 'pointnet_model'):
                # Check if model path is set
                if not hasattr(self, 'pointnet_model_path'):
                    self.pointnet_model_path = "/home/dalek/attempt_1/pointnet_detector.pth"
                    self.get_logger().info(f"Using default PointNet model path: {self.pointnet_model_path}")
                
                # Load PointNet model
                if os.path.exists(self.pointnet_model_path):
                    self.get_logger().info(f"Loading PointNet model from {self.pointnet_model_path}")
                    self.pointnet_model = torch.load(self.pointnet_model_path, map_location=torch.device('cpu'))
                    self.pointnet_model.eval()  # Set to evaluation mode
                else:
                    self.get_logger().error(f"PointNet model not found at {self.pointnet_model_path}")
                    return []
            
            # Need to preprocess point cloud for PointNet
            if len(lidar_points) < 10:  # Need minimum number of points
                return []
                
            # Here we would normally preprocess the points for PointNet
            # For demonstration, we'll simulate detections
            # In a real implementation, you would run the model on the points
            
            # Find clusters of points that might be cones
            # This is a simplified approach - real implementation would use the PointNet model
            detected_cones = []
            
            # Simple clustering - find points close to ground and cluster them
            # In 3D space, cones are typically small clusters of points
            ground_height = np.min(lidar_points[:, 2]) + 0.1  # Slightly above ground
            
            # Filter points close to ground
            near_ground_mask = (lidar_points[:, 2] < ground_height + 0.5) & (lidar_points[:, 2] > ground_height)
            near_ground_points = lidar_points[near_ground_mask]
            
            if len(near_ground_points) > 5:
                # Very simple clustering - just for demonstration
                # A real implementation would use DBSCAN or another clustering algorithm
                
                # Cluster points
                clustering = DBSCAN(eps=0.5, min_samples=5).fit(near_ground_points[:, :3])
                labels = clustering.labels_
                
                # Get cluster centers
                unique_labels = set(labels)
                for label in unique_labels:
                    if label != -1:  # Ignore noise
                        cluster_points = near_ground_points[labels == label]
                        center = np.mean(cluster_points, axis=0)
                        
                        # Simple size check - cones are small
                        max_distance = np.max(np.sqrt(np.sum((cluster_points - center)**2, axis=1)))
                        if max_distance < 0.5:  # Cones are typically small
                            # This is a potential cone
                            confidence = 0.7  # Simulated confidence
                            detected_cones.append({
                                'position': center,
                                'confidence': confidence,
                                'size': [0.3, 0.3, 0.4]  # Approximate cone size
                            })
            
            self.get_logger().info(f"Detected {len(detected_cones)} cones from LiDAR using PointNet")
            return detected_cones
            
        except Exception as e:
            self.get_logger().error(f"Error in PointNet detection: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return []

    def visualize_3d_cones(self, detected_cones):
        """
        Visualize detected cones as 3D markers in RViz
        
        Args:
            detected_cones: List of dictionaries containing cone position and confidence
        """
        try:
            marker_array = MarkerArray()
            
            for i, cone in enumerate(detected_cones):
                # Create a cone marker
                marker = Marker()
                marker.header.frame_id = "map"
                marker.header.stamp = self.get_clock().now().to_msg()
                marker.ns = "lidar_cones"
                marker.id = i
                marker.type = Marker.CYLINDER  # Use cylinder for cone
                marker.action = Marker.ADD
                
                # Set position
                marker.pose.position.x = cone['position'][0]
                marker.pose.position.y = cone['position'][1]
                marker.pose.position.z = cone['position'][2]
                
                # Set orientation (upright)
                marker.pose.orientation.x = 0.0
                marker.pose.orientation.y = 0.0
                marker.pose.orientation.z = 0.0
                marker.pose.orientation.w = 1.0
                
                # Set scale
                marker.scale.x = cone['size'][0]  # Diameter
                marker.scale.y = cone['size'][1]  # Diameter
                marker.scale.z = cone['size'][2]  # Height
                
                # Set color based on confidence
                confidence = cone['confidence']
                marker.color.r = 1.0
                marker.color.g = confidence  # Higher confidence = more yellow
                marker.color.b = 0.0
                marker.color.a = 0.8  # Slightly transparent
                
                # Make it persistent for a while
                marker.lifetime.sec = 1
                
                marker_array.markers.append(marker)
            
            # Publish the marker array
            self.cone_marker_pub.publish(marker_array)
            
        except Exception as e:
            self.get_logger().error(f"Error visualizing cones: {str(e)}")

    def process_lidar_data(self):
        """Process and publish LiDAR data."""
        if self.lidar is None or not hasattr(self, 'lidar_data') or self.lidar_data is None:
            return
            
        try:
            # Get sensor (LiDAR) world transformation matrix
            sensor_transform = np.array(self.lidar.get_transform().get_matrix())
            
            # Transform LiDAR points from sensor to world coordinates
            with self.lidar_lock:
                lidar_data = self.lidar_data.copy()
            
            if lidar_data.size == 0:
                self.get_logger().warn("No LiDAR points to process")
                return
                
            # Filter out points that are too far away (limit range to make visualization better)
            distances = np.sqrt(np.sum(lidar_data**2, axis=1))
            close_points_mask = distances < 50.0  # Filter to 50 meters
            lidar_data = lidar_data[close_points_mask]
            
            # Transform points to world coordinates
            points_world = transform_points(lidar_data, sensor_transform)
            
            # Accumulate points across multiple frames to increase density
            with self.lidar_history_lock:
                self.lidar_history.append(points_world)
                if len(self.lidar_history) > self.accumulate_frames:
                    self.lidar_history.pop(0)  # Remove oldest frame
                
                # Combine points from all frames in history
                all_points = np.vstack(self.lidar_history)
            
            # Detect cones from LiDAR points
            detected_cones = self.detect_cones_from_lidar(all_points)
            
            # Visualize detected cones
            self.visualize_3d_cones(detected_cones)
            
            # Create PointCloud2 header
            header = Header()
            header.stamp = self.get_clock().now().to_msg()
            header.frame_id = "map"  # Use map as frame to avoid tf issues
            
            # Debug info
            self.get_logger().info(f"Publishing {len(all_points)} accumulated LiDAR points")
            
            # Create colored point cloud
            fields = [
                pc2.PointField(name='x', offset=0, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='y', offset=4, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='z', offset=8, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='intensity', offset=12, datatype=pc2.PointField.FLOAT32, count=1)
            ]
            
            # Create structured array for colored points
            structured_points = np.zeros(len(all_points), 
                                        dtype=[
                                            ('x', np.float32),
                                            ('y', np.float32),
                                            ('z', np.float32),
                                            ('intensity', np.float32)
                                        ])
            
            # Fill structured array
            structured_points['x'] = all_points[:, 0]
            structured_points['y'] = all_points[:, 1]
            structured_points['z'] = all_points[:, 2]
            
            # Color points based on height (z value)
            # Normalize z value to get a good color range
            min_z = np.min(all_points[:, 2])
            max_z = np.max(all_points[:, 2])
            z_range = max_z - min_z
            if z_range > 0:
                # Normalize to range 0-1
                intensity = (all_points[:, 2] - min_z) / z_range
            else:
                intensity = np.ones(len(all_points))
            
            structured_points['intensity'] = intensity
            
            # Create and publish the point cloud
            pc_msg = pc2.create_cloud(header, fields, structured_points)
            self.lidar_pub.publish(pc_msg)
            
        except Exception as e:
            self.get_logger().error(f"Error processing LiDAR data: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def fuse_data(self):
        """Fuse LiDAR and camera data."""
        if self.zed_camera is None or self.zed_camera.rgb_image is None or self.zed_camera.depth_image is None:
            return
            
        if self.lidar_data is None:
            return
            
        try:
            # Get depth image
            depth_array, _ = self.zed_camera.depth_image
            
            # Project LiDAR points to camera image
            lidar_transform = np.array(self.lidar.get_transform().get_matrix())
            camera_transform = np.array(self.zed_camera.rgb_sensor.get_transform().get_matrix())
            
            # Calculate relative transform from LiDAR to camera
            lidar_to_camera = np.linalg.inv(camera_transform) @ lidar_transform
            
            # Copy LiDAR data to avoid race conditions
            with self.lidar_lock:
                lidar_data = self.lidar_data.copy()
            
            # Transform LiDAR points to camera frame
            points_camera_frame = transform_points(lidar_data, lidar_to_camera)
            
            # Simple data fusion: Filter LiDAR points by camera FOV and depth
            # This is a basic fusion - more sophisticated methods can be implemented
            valid_points = []
            colors = []
            
            for i, point in enumerate(points_camera_frame):
                # Only keep points in front of camera
                if point[2] <= 0:
                    continue
                    
                # Project point to image
                x, y, z = point
                
                # Basic pinhole camera model (approximation)
                # This should be replaced with proper camera calibration parameters
                fx = 800.0  # focal length x
                fy = 800.0  # focal length y
                cx = 640.0  # optical center x
                cy = 360.0  # optical center y
                
                u = int(fx * x / z + cx)
                v = int(fy * y / z + cy)
                
                # Check if point projects into image
                if (0 <= u < 1280 and 0 <= v < 720):
                    # Get depth from depth image at projected point
                    if depth_array is not None:
                        camera_depth = depth_array[v, u] if v < depth_array.shape[0] and u < depth_array.shape[1] else 0
                        
                        # Compare LiDAR depth with camera depth
                        lidar_depth = np.abs(z)
                        
                        # If depths are similar, consider it a valid fusion point
                        if camera_depth > 0 and abs(lidar_depth - camera_depth) < 2.0:
                            valid_points.append(point)
                            
                            # Get color from RGB image
                            if self.zed_camera.rgb_image is not None:
                                r, g, b = self.zed_camera.rgb_image[v, u]
                                colors.append([r/255.0, g/255.0, b/255.0])
                            else:
                                colors.append([1.0, 1.0, 1.0])  # White if no color available
            
            # Create fused colored point cloud
            if valid_points:
                fused_points = np.array(valid_points)
                
                # Transform back to world frame
                fused_points_world = transform_points(fused_points, camera_transform)
                
                # Create PointCloud2 message for fused points
                header = Header()
                header.stamp = self.get_clock().now().to_msg()
                header.frame_id = "map"
                
                # Publisher requires a structured point cloud with fields
                # We'll create an uncolored point cloud for simplicity
                pc_msg = pc2.create_cloud_xyz32(header, fused_points_world)
                self.fused_pub.publish(pc_msg)
                
                # For colored point cloud:
                # fields = [PointField(name='x', offset=0, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='y', offset=4, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='z', offset=8, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='r', offset=12, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='g', offset=16, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='b', offset=20, datatype=PointField.FLOAT32, count=1)]
                
                self.get_logger().debug(f"Published {len(valid_points)} fused points")
        except Exception as e:
            self.get_logger().error(f"Error in data fusion: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def publish_data(self):
        """Publish camera and path planning data."""
        if (self.zed_camera is None or 
            not hasattr(self.zed_camera, 'rgb_image') or 
            not hasattr(self.zed_camera, 'depth_image') or
            self.zed_camera.rgb_image is None or 
            self.zed_camera.depth_image is None):
            return
            
        try:
            # RGB image
            rgb_img = self.zed_camera.rgb_image.copy()
            rgb_msg = self.bridge.cv2_to_imgmsg(rgb_img, encoding="bgr8")
            rgb_msg.header.stamp = self.get_clock().now().to_msg()
            rgb_msg.header.frame_id = "camera_link"
            self.rgb_pub.publish(rgb_msg)
            
            # Depth image
            _, depth_img = self.zed_camera.depth_image
            if depth_img is not None:
                depth_msg = self.bridge.cv2_to_imgmsg(depth_img, encoding="bgr8")
                depth_msg.header.stamp = self.get_clock().now().to_msg()
                depth_msg.header.frame_id = "camera_link"
                self.depth_pub.publish(depth_msg)
            
            # Path visualization
            if self.path_planner and rgb_img is not None:
                path_img = self.path_planner.draw_path(rgb_img.copy())
                path_msg = self.bridge.cv2_to_imgmsg(path_img, encoding="bgr8")
                path_msg.header.stamp = self.get_clock().now().to_msg()
                path_msg.header.frame_id = "camera_link"
                self.path_pub.publish(path_msg)
                
        except Exception as e:
            self.get_logger().error(f"Error publishing data: {str(e)}")
    
    def broadcast_tf(self):
        """Broadcast transforms for the tf tree."""
        if not self.vehicle:
            return
            
        try:
            # Get current time
            now = self.get_clock().now()
            
            # Broadcast vehicle frame
            vehicle_t = TransformStamped()
            vehicle_t.header.stamp = now.to_msg()
            vehicle_t.header.frame_id = "map"
            vehicle_t.child_frame_id = "vehicle"
            
            vehicle_loc = self.vehicle.get_location()
            vehicle_rot = self.vehicle.get_transform().rotation
            
            vehicle_t.transform.translation.x = vehicle_loc.x
            vehicle_t.transform.translation.y = vehicle_loc.y
            vehicle_t.transform.translation.z = vehicle_loc.z
            
            # Convert roll, pitch, yaw to quaternion
            # This is a simplified conversion, a proper conversion should be used
            cy = np.cos(np.radians(vehicle_rot.yaw) * 0.5)
            sy = np.sin(np.radians(vehicle_rot.yaw) * 0.5)
            cr = np.cos(np.radians(vehicle_rot.roll) * 0.5)
            sr = np.sin(np.radians(vehicle_rot.roll) * 0.5)
            cp = np.cos(np.radians(vehicle_rot.pitch) * 0.5)
            sp = np.sin(np.radians(vehicle_rot.pitch) * 0.5)
            
            qw = cy * cr * cp + sy * sr * sp
            qx = cy * sr * cp - sy * cr * sp
            qy = cy * cr * sp + sy * sr * cp
            qz = sy * cr * cp - cy * sr * sp
            
            vehicle_t.transform.rotation.w = qw
            vehicle_t.transform.rotation.x = qx
            vehicle_t.transform.rotation.y = qy
            vehicle_t.transform.rotation.z = qz
            
            self.tf_broadcaster.sendTransform(vehicle_t)
            
            # Broadcast camera frame
            if self.zed_camera and self.zed_camera.rgb_sensor:
                camera_t = TransformStamped()
                camera_t.header.stamp = now.to_msg()
                camera_t.header.frame_id = "vehicle"
                camera_t.child_frame_id = "camera_link"
                
                camera_loc = self.zed_camera.rgb_sensor.get_transform().location
                camera_rot = self.zed_camera.rgb_sensor.get_transform().rotation
                
                camera_t.transform.translation.x = camera_loc.x
                camera_t.transform.translation.y = camera_loc.y
                camera_t.transform.translation.z = camera_loc.z
                
                # Convert roll, pitch, yaw to quaternion
                cy = np.cos(np.radians(camera_rot.yaw) * 0.5)
                sy = np.sin(np.radians(camera_rot.yaw) * 0.5)
                cr = np.cos(np.radians(camera_rot.roll) * 0.5)
                sr = np.sin(np.radians(camera_rot.roll) * 0.5)
                cp = np.cos(np.radians(camera_rot.pitch) * 0.5)
                sp = np.sin(np.radians(camera_rot.pitch) * 0.5)
                
                qw = cy * cr * cp + sy * sr * sp
                qx = cy * sr * cp - sy * cr * sp
                qy = cy * cr * sp + sy * sr * cp
                qz = sy * cr * cp - cy * sr * sp
                
                camera_t.transform.rotation.w = qw
                camera_t.transform.rotation.x = qx
                camera_t.transform.rotation.y = qy
                camera_t.transform.rotation.z = qz
                
                self.tf_broadcaster.sendTransform(camera_t)
            
            # Broadcast LiDAR frame
            if self.lidar:
                lidar_t = TransformStamped()
                lidar_t.header.stamp = now.to_msg()
                lidar_t.header.frame_id = "vehicle"
                lidar_t.child_frame_id = "lidar_link"
                
                lidar_loc = self.lidar.get_transform().location
                lidar_rot = self.lidar.get_transform().rotation
                
                lidar_t.transform.translation.x = lidar_loc.x
                lidar_t.transform.translation.y = lidar_loc.y
                lidar_t.transform.translation.z = lidar_loc.z
                
                # Convert roll, pitch, yaw to quaternion
                cy = np.cos(np.radians(lidar_rot.yaw) * 0.5)
                sy = np.sin(np.radians(lidar_rot.yaw) * 0.5)
                cr = np.cos(np.radians(lidar_rot.roll) * 0.5)
                sr = np.sin(np.radians(lidar_rot.roll) * 0.5)
                cp = np.cos(np.radians(lidar_rot.pitch) * 0.5)
                sp = np.sin(np.radians(lidar_rot.pitch) * 0.5)
                
                qw = cy * cr * cp + sy * sr * sp
                qx = cy * sr * cp - sy * cr * sp
                qy = cy * cr * sp + sy * sr * cp
                qz = sy * cr * cp - cy * sr * sp
                
                lidar_t.transform.rotation.w = qw
                lidar_t.transform.rotation.x = qx
                lidar_t.transform.rotation.y = qy
                lidar_t.transform.rotation.z = qz
                
                self.tf_broadcaster.sendTransform(lidar_t)
                
        except Exception as e:
            self.get_logger().error(f"Error broadcasting transforms: {str(e)}")
    
    def visualization_thread(self):
        """Thread for OpenCV visualization."""
        while self.show_opencv_windows:
            try:
                if (self.zed_camera is not None and 
                    hasattr(self.zed_camera, 'rgb_image') and 
                    self.zed_camera.rgb_image is not None):
                    
                    # Show RGB image with detections
                    cv2.imshow('RGB Image with Detections', self.zed_camera.rgb_image)
                    
                    # Show depth image if available
                    if (hasattr(self.zed_camera, 'depth_image') and 
                        self.zed_camera.depth_image is not None):
                        _, depth_img = self.zed_camera.depth_image
                        if depth_img is not None:
                            cv2.imshow('Depth Image', depth_img)
                    
                    # Break loop if 'q' is pressed
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        self.show_opencv_windows = False
                        break
                    
                    time.sleep(0.05)  # 20 Hz refresh rate
                else:
                    time.sleep(0.1)  # Slower refresh rate when no data
                    
            except Exception as e:
                self.get_logger().error(f"Error in visualization thread: {str(e)}")
                time.sleep(0.1)
        
        cv2.destroyAllWindows()
    
    def destroy_node(self):
        """Clean up resources on node shutdown."""
        self.get_logger().info("Shutting down fusion node...")
        
        # Disable OpenCV windows
        self.show_opencv_windows = False
        if self.vis_thread and self.vis_thread.is_alive():
            self.vis_thread.join(timeout=1.0)
        
        # Clean up Carla resources
        if self.lidar:
            self.lidar.stop()
            self.lidar.destroy()
            self.get_logger().info("LiDAR sensor destroyed")
        
        if self.zed_camera:
            self.zed_camera.shutdown()
            self.get_logger().info("ZED camera shut down")
        
        if self.vehicle:
            self.vehicle.destroy()
            self.get_logger().info("Vehicle destroyed")
        
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = LidarCameraFusionNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Error in main: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Clean up
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
