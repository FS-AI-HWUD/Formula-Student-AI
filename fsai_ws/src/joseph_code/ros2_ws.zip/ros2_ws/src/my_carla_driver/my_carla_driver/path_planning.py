import numpy as np
from scipy.interpolate import CubicSpline
import cv2

class PathPlanner:
    def __init__(self, zed_camera, depth_min=0.5, depth_max=12.5, cone_spacing=1.5, visualize=True):
        self.zed_camera = zed_camera
        self.depth_min = depth_min
        self.depth_max = depth_max
        self.cone_spacing = cone_spacing
        self.visualize = visualize
        self.path = None
        self.previous_path = None  # Store the previous path for temporal smoothing
        self.image_width = zed_camera.resolution[0]
        self.image_height = zed_camera.resolution[1]
        self.fov_horizontal = 90.0
        self.wheelbase = 2.7
    
    def _filter_cones(self, cones, depths):
        filtered_cones = []
        filtered_depths = []
        
        print("Skipping depth corridor filter as requested...")
        for (x1, y1, x2, y2, cls), depth in zip(cones, depths):
            center_x = (x1 + x2) // 2
            center_y = (y1 + y2) // 2
            filtered_cones.append((center_x, center_y, cls))
            filtered_depths.append(depth)
            print(f"Kept cone: Class = {cls}, Depth = {depth:.2f}m, Center = ({center_x}, {center_y})")
        
        print(f"Total cones after removing filter: {len(filtered_cones)}")
        return filtered_cones, filtered_depths
    
    def _pair_cones(self, cones, depths):
        yellow_cones = [(c, d) for c, d in zip(cones, depths) if c[2] == 0]
        blue_cones = [(c, d) for c, d in zip(cones, depths) if c[2] == 1]
        
        print(f"Yellow cones: {len(yellow_cones)}, Blue cones: {len(blue_cones)}")
        for cone, depth in yellow_cones:
            print(f"Yellow cone at depth {depth:.2f}m, Center = ({cone[0]}, {cone[1]})")
        for cone, depth in blue_cones:
            print(f"Blue cone at depth {depth:.2f}m, Center = ({cone[0]}, {cone[1]})")
        
        yellow_world = []
        for cone, depth in yellow_cones:
            center_x = cone[0]
            angle = ((center_x - self.image_width / 2) / (self.image_width / 2)) * (self.fov_horizontal / 2)
            world_x = depth * np.tan(np.radians(angle))
            yellow_world.append((world_x, depth))
        
        blue_world = []
        for cone, depth in blue_cones:
            center_x = cone[0]
            angle = ((center_x - self.image_width / 2) / (self.image_width / 2)) * (self.fov_horizontal / 2)
            world_x = depth * np.tan(np.radians(angle))
            blue_world.append((world_x, depth))
        
        print("World coordinates:")
        for x, d in yellow_world:
            print(f"Yellow cone: x = {x:.2f}m, depth = {d:.2f}m")
        for x, d in blue_world:
            print(f"Blue cone: x = {x:.2f}m, depth = {d:.2f}m")
        
        yellow_on_right = sum(1 for x, _ in yellow_world if x > 0) > len(yellow_world) / 2 if yellow_world else False
        blue_on_left = sum(1 for x, _ in blue_world if x < 0) > len(blue_world) / 2 if blue_world else False
        
        if not (yellow_on_right and blue_on_left):
            print("WARNING: Cone positions appear inverted. Manual correction applied.")
            yellow_world = [(-x, d) for x, d in yellow_world]
            blue_world = [(-x, d) for x, d in blue_world]
            print("World coordinates after flipping:")
            for x, d in yellow_world:
                print(f"Yellow cone: x = {x:.2f}m, depth = {d:.2f}m")
            for x, d in blue_world:
                print(f"Blue cone: x = {x:.2f}m, depth = {d:.2f}m")
        
        yellow_world.sort(key=lambda p: p[1])
        blue_world.sort(key=lambda p: p[1])
        
        # Outlier detection for yellow and blue cones
        filtered_yellow_world = []
        last_yellow_x = None
        for yx, yd in yellow_world:
            if last_yellow_x is not None:
                delta_x = abs(yx - last_yellow_x)
                if delta_x > 5.0:
                    print(f"Outlier detected: Yellow cone at depth {yd:.2f}m, x = {yx:.2f}m, delta_x = {delta_x:.2f}m")
                    continue
            filtered_yellow_world.append((yx, yd))
            last_yellow_x = yx
        
        filtered_blue_world = []
        last_blue_x = None
        for bx, bd in blue_world:
            if last_blue_x is not None:
                delta_x = abs(bx - last_blue_x)
                if delta_x > 5.0:
                    print(f"Outlier detected: Blue cone at depth {bd:.2f}m, x = {bx:.2f}m, delta_x = {delta_x:.2f}m")
                    continue
            filtered_blue_world.append((bx, bd))
            last_blue_x = bx
        
        yellow_world = filtered_yellow_world
        blue_world = filtered_blue_world
        
        print("World coordinates after outlier removal:")
        for x, d in yellow_world:
            print(f"Yellow cone: x = {x:.2f}m, depth = {d:.2f}m")
        for x, d in blue_world:
            print(f"Blue cone: x = {x:.2f}m, depth = {d:.2f}m")
        
        waypoints = [(0.0, 0.5)]
        
        track_widths = []
        for y_x, y_d in yellow_world:
            for b_x, b_d in blue_world:
                if abs(y_d - b_d) < 3.0:
                    width = y_x - b_x
                    if 2.0 < width < 6.0:
                        track_widths.append(width)
        
        default_track_width = 5.0
        track_width = default_track_width
        if track_widths:
            track_width = np.median(track_widths)
            print(f"Calculated track width: {track_width:.2f}m from {len(track_widths)} cone pairs")
        else:
            print(f"Using default track width: {track_width:.2f}m")
        
        min_depth = 0.5
        max_depth = 20.0
        depth_interval = 0.5
        
        sample_depths = np.arange(min_depth, max_depth, depth_interval)
        
        last_yellow_x = None
        last_blue_x = None
        last_midpoint_x = 0.0
        
        yellow_x_coords = [p[0] for p in yellow_world]
        yellow_depths = [p[1] for p in yellow_world]
        blue_x_coords = [p[0] for p in blue_world]
        blue_depths = [p[1] for p in blue_world]
        
        # Track the trend of yellow and blue cones to detect straight sections
        yellow_trend = 0.0
        blue_trend = 0.0
        if len(yellow_world) > 1:
            yellow_deltas = [(yellow_world[i][0] - yellow_world[i-1][0]) / (yellow_world[i][1] - yellow_world[i-1][1])
                            for i in range(1, len(yellow_world))]
            yellow_trend = np.mean(yellow_deltas) if yellow_deltas else 0.0
        if len(blue_world) > 1:
            blue_deltas = [(blue_world[i][0] - blue_world[i-1][0]) / (blue_world[i][1] - blue_world[i-1][1])
                           for i in range(1, len(blue_world))]
            blue_trend = np.mean(blue_deltas) if blue_deltas else 0.0
        
        print(f"Yellow cone trend: {yellow_trend:.3f}, Blue cone trend: {blue_trend:.3f}")
        
        for depth in sample_depths:
            closest_yellow = None
            closest_blue = None
            min_yellow_diff = float('inf')
            min_blue_diff = float('inf')
            
            for y_x, y_d in yellow_world:
                diff = abs(y_d - depth)
                if diff < min_yellow_diff:
                    min_yellow_diff = diff
                    closest_yellow = (y_x, y_d)
            
            for b_x, b_d in blue_world:
                diff = abs(b_d - depth)
                if diff < min_blue_diff:
                    min_blue_diff = diff
                    closest_blue = (b_x, b_d)
            
            max_diff = 8.0
            
            yellow_x = None
            blue_x = None
            
            if closest_yellow and min_yellow_diff < max_diff:
                yellow_x = closest_yellow[0]
                last_yellow_x = yellow_x
                print(f"Found yellow cone at depth {depth:.2f}m, x = {yellow_x:.2f}m")
            elif last_yellow_x is not None and len(yellow_depths) > 1:
                yellow_x = np.interp(depth, yellow_depths, yellow_x_coords)
                print(f"Interpolating yellow cone at depth {depth:.2f}m: x = {yellow_x:.2f}")
            
            if closest_blue and min_blue_diff < max_diff:
                blue_x = closest_blue[0]
                last_blue_x = blue_x
                print(f"Found blue cone at depth {depth:.2f}m, x = {blue_x:.2f}m")
            elif last_blue_x is not None and len(blue_depths) > 1:
                blue_x = np.interp(depth, blue_depths, blue_x_coords)
                print(f"Interpolating blue cone at depth {depth:.2f}m: x = {blue_x:.2f}")
            
            if yellow_x is None and blue_x is not None:
                yellow_x = blue_x + track_width
                print(f"Estimating yellow cone at depth {depth:.2f}m based on blue cone: {yellow_x:.2f}")
            elif blue_x is None and yellow_x is not None:
                blue_x = yellow_x - track_width
                print(f"Estimating blue cone at depth {depth:.2f}m based on yellow cone: {blue_x:.2f}")
            
            if yellow_x is not None and blue_x is not None:
                print(f"Comparing yellow_x = {yellow_x:.2f}, blue_x = {blue_x:.2f} at depth {depth:.2f}m")
                if yellow_x > blue_x:
                    midpoint_x = (yellow_x + blue_x) / 2
                    # Apply stricter smoothing in straight sections
                    if depth > 0.5:
                        # Relax the threshold for straight sections
                        is_straight = abs(yellow_trend) < 0.2 and abs(blue_trend) < 0.2
                        delta_midpoint = abs(midpoint_x - last_midpoint_x)
                        if is_straight:
                            midpoint_x = 0.3 * midpoint_x + 0.7 * last_midpoint_x
                            print(f"Straight section detected. Applying strict smoothing.")
                        elif delta_midpoint > 2.0:
                            midpoint_x = 0.9 * midpoint_x + 0.1 * last_midpoint_x
                            print(f"Large midpoint change detected. Applying light smoothing.")
                        else:
                            midpoint_x = 0.7 * midpoint_x + 0.3 * last_midpoint_x
                            print(f"Normal smoothing applied.")
                    waypoints.append((midpoint_x, depth))
                    last_midpoint_x = midpoint_x
                    print(f"Adding midpoint waypoint at ({midpoint_x:.2f}, {depth:.2f}m)")
                else:
                    print(f"Warning: Cone positions inverted at depth {depth:.2f}m")
                    if last_yellow_x is not None and last_blue_x is not None:
                        midpoint_x = (last_yellow_x + last_blue_x) / 2
                        midpoint_x = 0.7 * midpoint_x + 0.3 * last_midpoint_x
                        waypoints.append((midpoint_x, depth))
                        last_midpoint_x = midpoint_x
                        print(f"Using last known midpoint at ({midpoint_x:.2f}, {depth:.2f}m)")
                    else:
                        waypoints.append((last_midpoint_x, depth))
                        print(f"Fallback to last midpoint at ({last_midpoint_x:.2f}, {depth:.2f}m)")
            else:
                if last_yellow_x is not None and last_blue_x is not None:
                    midpoint_x = (last_yellow_x + last_blue_x) / 2
                    midpoint_x = 0.7 * midpoint_x + 0.3 * last_midpoint_x
                    waypoints.append((midpoint_x, depth))
                    last_midpoint_x = midpoint_x
                    print(f"Using last known midpoint at ({midpoint_x:.2f}, {depth:.2f}m) due to missing cones")
                else:
                    waypoints.append((last_midpoint_x, depth))
                    print(f"Fallback to last midpoint at ({last_midpoint_x:.2f}, {depth:.2f}m) due to missing cones")
        
        if len(waypoints) > 1:
            filtered_waypoints = [waypoints[0]]
            for i in range(1, len(waypoints)):
                curr_x, curr_y = waypoints[i]
                prev_x, prev_y = filtered_waypoints[-1]
                dist = np.sqrt((curr_x - prev_x)**2 + (curr_y - prev_y)**2)
                if dist > 0.3:
                    filtered_waypoints.append(waypoints[i])
            waypoints = filtered_waypoints
        
        if len(waypoints) > 2:
            smoothed_x = [waypoints[0][0]]
            window_size = 5
            for i in range(1, len(waypoints) - 1):
                start_idx = max(0, i - window_size // 2)
                end_idx = min(len(waypoints), i + 1 + window_size // 2)
                window = waypoints[start_idx:end_idx]
                avg_x = sum(w[0] for w in window) / len(window)
                smoothed_x.append(avg_x)
            smoothed_x.append(waypoints[-1][0])
            smoothed_waypoints = [(x, waypoints[i][1]) for i, x in enumerate(smoothed_x)]
            waypoints = smoothed_waypoints
        
        print(f"Final waypoints: {len(waypoints)}")
        return waypoints
    
    def _smooth_path(self, x_coords, y_coords):
        if len(x_coords) < 2:
            print("Not enough waypoints for path planning")
            return np.array([0]), np.array([0])
        
        x_coords = np.array(x_coords)
        y_coords = np.array(y_coords)
        
        indices = np.argsort(y_coords)
        x_coords = x_coords[indices]
        y_coords = y_coords[indices]
        
        num_points = 100
        
        if len(x_coords) <= 3:
            t = np.linspace(0, 1, num_points)
            x_interp = np.interp(t, np.linspace(0, 1, len(x_coords)), x_coords)
            y_interp = np.interp(t, np.linspace(0, 1, len(y_coords)), y_coords)
            return x_interp, y_interp
        
        t = np.zeros(len(x_coords))
        for i in range(1, len(x_coords)):
            dx = x_coords[i] - x_coords[i-1]
            dy = y_coords[i] - y_coords[i-1]
            t[i] = t[i-1] + np.sqrt(dx*dx + dy*dy)
        
        if t[-1] > 0:
            t = t / t[-1]
        
        t_uniform = np.linspace(0, 1, num_points)
        x_smooth = np.interp(t_uniform, t, x_coords)
        y_smooth = np.interp(t_uniform, t, y_coords)
        
        # Reintroduce light smoothing to reduce oscillations
        x_smooth = np.convolve(x_smooth, np.ones(3)/3, mode='same')
        y_smooth = np.convolve(y_smooth, np.ones(3)/3, mode='same')
        
        return x_smooth, y_smooth
    
    def _smooth_path_temporally(self, new_path):
        """Blend the new path with the previous path to reduce sudden jumps."""
        if self.previous_path is None or len(self.previous_path) != len(new_path):
            self.previous_path = new_path
            return new_path
        
        alpha = 0.7  # Smoothing factor (0 = use previous path, 1 = use new path)
        smoothed_path = []
        for (new_x, new_y), (prev_x, prev_y) in zip(new_path, self.previous_path):
            smoothed_x = alpha * new_x + (1 - alpha) * prev_x
            smoothed_y = alpha * new_y + (1 - alpha) * prev_y
            smoothed_path.append((smoothed_x, smoothed_y))
        
        self.previous_path = smoothed_path
        return smoothed_path
    
    def calculate_steering(self, lookahead_distance=5.0):
        if self.path is None or len(self.path) < 2:
            return 0.0
        
        cumulative_dist = [0]
        for i in range(1, len(self.path)):
            x1, y1 = self.path[i-1]
            x2, y2 = self.path[i]
            segment_length = np.sqrt((x2-x1)**2 + (y2-y1)**2)
            cumulative_dist.append(cumulative_dist[-1] + segment_length)
        
        target_dist = lookahead_distance
        target_idx = 0
        
        for i, dist in enumerate(cumulative_dist):
            if dist >= target_dist:
                target_idx = i
                break
        
        if target_idx > 0 and target_idx < len(self.path):
            target_x, target_y = self.path[target_idx]
            angle = np.arctan2(target_x, target_y)
            max_angle = np.radians(30)
            normalized_steering = np.clip(angle / max_angle, -1.0, 1.0)
            return normalized_steering
        
        return 0.0
    
    def plan_path(self):
        try:
            if not self.zed_camera.cone_detections:
                print("No cone detections available")
                self.path = None
                return
            
            cones = []
            depths = []
            for detection in self.zed_camera.cone_detections:
                x1, y1, x2, y2 = detection['box']
                cls = detection['cls']
                depth = detection['depth']
                print(f"Using cone: Class = {cls}, Depth = {depth:.2f}m, Box = ({x1}, {y1}, {x2}, {y2})")
                cones.append((x1, y1, x2, y2, cls))
                depths.append(depth)
            
            print(f"Using {len(cones)} detected cones from zed_2i.py")
            
            filtered_cones, filtered_depths = self._filter_cones(cones, depths)
            if not filtered_cones:
                print("No cones after filtering")
                self.path = None
                return
            
            yellow_cones = [(c, d) for c, d in zip(filtered_cones, filtered_depths) if c[2] == 0]
            blue_cones = [(c, d) for c, d in zip(filtered_cones, filtered_depths) if c[2] == 1]
            print(f"Yellow cones: {len(yellow_cones)}, Blue cones: {len(blue_cones)}")
            
            waypoints = self._pair_cones(filtered_cones, filtered_depths)
            
            if waypoints:
                x_coords, y_coords = zip(*waypoints)
                smoothed_x, smoothed_y = self._smooth_path(x_coords, y_coords)
                new_path = list(zip(smoothed_x, smoothed_y))
                
                # Apply temporal smoothing
                new_path = self._smooth_path_temporally(new_path)
                
                # Sort the path by depth to ensure smooth drawing
                new_path.sort(key=lambda p: p[1])
                self.path = new_path
                
                print(f"Path successfully created with {len(self.path)} points!")
            else:
                print("No waypoints found")
                self.path = None
                
        except Exception as e:
            print(f"Error in path planning: {e}")
            self.path = None
    
    def draw_path(self, image):
        if not self.visualize or self.path is None or len(self.path) < 2:
            return image
        
        car_x = self.image_width // 2  # 640
        car_y = self.image_height - 20  # 700
        
        car_points = np.array([
            [car_x, car_y - 10],
            [car_x - 10, car_y + 10],
            [car_x + 10, car_y + 10]
        ], dtype=np.int32)
        cv2.fillPoly(image, [car_points], (0, 255, 255))
        
        path_pixels = [(car_x, car_y)]
        
        # Calibrate the depth-to-pixel mapping using cone positions
        cone_positions = []
        for detection in self.zed_camera.cone_detections:
            x1, y1, x2, y2 = detection['box']
            depth = detection['depth']
            bottom_y = y2
            cone_positions.append((depth, bottom_y))
        cone_positions.sort(key=lambda x: x[0])  # Sort by depth
        
        if cone_positions:
            min_cone_depth, min_cone_y = cone_positions[0]
            max_cone_depth, max_cone_y = cone_positions[-1]
        else:
            min_cone_depth, min_cone_y = 1.0, self.image_height - 30
            max_cone_depth, max_cone_y = 20.0, self.image_height * 0.4
        
        start_depth = self.path[0][1]  # Depth of the first path point (0.5m)
        start_y = car_y  # Start at the car's position
        depth_range = max_cone_depth - start_depth
        y_range = min_cone_y - max_cone_y
        
        for i, (world_x, world_y) in enumerate(self.path[1:]):
            angle_x = np.arctan2(world_x, world_y)
            pixel_x = int((angle_x / np.radians(self.fov_horizontal / 2)) * 
                         (self.image_width / 2) + (self.image_width / 2))
            
            if depth_range > 0:
                t = (world_y - start_depth) / depth_range
                if world_y <= min_cone_depth:
                    t_start = (world_y - start_depth) / (min_cone_depth - start_depth)
                    pixel_y = int(car_y - t_start * (car_y - min_cone_y))
                else:
                    t_cone = (world_y - min_cone_depth) / (max_cone_depth - min_cone_depth)
                    pixel_y = int(min_cone_y - t_cone * y_range)
            else:
                pixel_y = car_y
            
            pixel_y = max(0, min(pixel_y, self.image_height - 1))
            pixel_x = max(0, min(pixel_x, self.image_width - 1))
            path_pixels.append((pixel_x, pixel_y))
        
        # Draw the path
        if len(path_pixels) >= 2:
            cv2.polylines(image, [np.array(path_pixels)], False, (0, 0, 0), 7)
            
            for i in range(len(path_pixels) - 1):
                ratio = i / (len(path_pixels) - 1)
                if ratio < 0.25:
                    r, g, b = 255, int(255 * ratio * 4), 0
                elif ratio < 0.5:
                    r, g, b = int(255 * (1 - (ratio - 0.25) * 4)), 255, 0
                elif ratio < 0.75:
                    r, g, b = 0, 255, int(255 * (ratio - 0.5) * 4)
                else:
                    r, g, b = 0, int(255 * (1 - (ratio - 0.75) * 4)), 255
                
                cv2.line(image, path_pixels[i], path_pixels[i + 1], (b, g, r), 5)
            
            for i in range(0, len(self.path), 5):
                if i < len(path_pixels) and i > 0:
                    x, y = path_pixels[i]
                    label = f"{self.path[i][1]:.1f}m"
                    cv2.putText(image, label, (x + 5, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 
                               0.5, (255, 255, 255), 2, cv2.LINE_AA)
                    cv2.circle(image, (x, y), 3, (255, 255, 255), -1)
            
            arrow_spacing = max(1, len(path_pixels) // 5)
            for i in range(0, len(path_pixels) - arrow_spacing, arrow_spacing):
                p1 = path_pixels[i]
                p2 = path_pixels[i + arrow_spacing]
                cv2.arrowedLine(image, p1, p2, (0, 0, 255), 2, tipLength=0.3)
        
        path_info = f"Path: {len(self.path)} points, {self.path[-1][1]:.1f}m"
        cv2.putText(image, path_info, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 0), 2, cv2.LINE_AA)
        
        steering = 0.0
        lookahead_distance = 5.0
        
        target_idx = 0
        for i, (_, depth) in enumerate(self.path):
            if depth >= lookahead_distance:
                target_idx = i
                break
        
        if target_idx < len(self.path):
            target_x, target_y = self.path[target_idx]
            angle = np.arctan2(target_x, target_y)
            max_angle = np.radians(30)
            steering = np.clip(angle / max_angle, -1.0, 1.0)
            
            if target_idx < len(path_pixels):
                tx, ty = path_pixels[target_idx]
                cv2.circle(image, (tx, ty), 8, (0, 0, 255), -1)
        
        steer_text = f"Steering: {steering:.2f}"
        cv2.putText(image, steer_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.7, (0, 255, 255), 2, cv2.LINE_AA)
        
        return image
    
    def get_path(self):
        return self.path
